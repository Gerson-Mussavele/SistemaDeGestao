const mongoose = require('mongoose')
const bcrypt  = require('bcrypt')
const validator = require('validator')
const jwt = require('jsonwebtoken')
const schema = mongoose.Schema;


//crear json Token
const criarToken = async function (_id) {
    return jwt.sign({_id}, process.env.SECRET)
}

const clienteSchema = new schema({
    name:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    phone:{
        type: String,
        required: true
    },
    address:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    }
}, {
    timestamps: true  // Configuração correta para timestamps
});



module.exports = mongoose.model('Cliente', clienteSchema);