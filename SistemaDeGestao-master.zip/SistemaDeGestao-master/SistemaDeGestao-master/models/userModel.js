const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const validator = require('validator');
const schema = mongoose.Schema;

const userSchema = new schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true // Ensure email uniqueness
  },
  password: {
    type: String,
    required: true
  },
  category: {
    type: String,
    default: "Cashier",
    enum: ["Cashier", "Admin"],
    required: true
  }

}, {
  timestamps: true
});

// Static function signup
userSchema.statics.signUp = async function (email, password, name) {
  // Input validation
  if (!email) {
    throw new Error('Please provide an email');
  }
  if (!password) {
    throw new Error('Please provide a password');
  }
  if (!validator.isEmail(email)) {
    throw new Error('Invalid email');
  }
  if (!validator.isStrongPassword(password)) {
    throw new Error('Weak password');
  }

  const emailExists = await this.findOne({ email });
  if (emailExists) {
    throw new Error('Email already exists');
  }

  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);

  const user = await this.create({ email,name , password: hash });
  return user;
};

// Static function logIn
userSchema.statics.logIn = async function (email, password) {
  if (!email) {
    throw new Error('Please provide an email');
  }
  if (!password) {
    throw new Error('Please provide a password');
  }

  const user = await this.findOne({ email });
  if (!user) {
    throw new Error('Incorrect email');
  }

  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    throw new Error('Invalid password');
  }

  return user;
};

module.exports = mongoose.model('User', userSchema);

