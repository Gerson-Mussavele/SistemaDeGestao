const express = require('express');
const {
    userLogin,
    userSignUp,
    adminArea, 
    cashierArea
} = require('../controllers/userController');
const {authorize} = require ('../Middleware/authUser')
const authMiddleware = require ('../Middleware/authMiddleware')
const router = express.Router();

//LogIn
router.post('/LogIn',userLogin);

//SignUp
router.post('/SignUp',userSignUp);

//Acesso
router.get('/Admin',authorize('Admin'),adminArea)

router.get('Cashier',authorize('Cashier'),cashierArea)

module.exports = router;