const User = require('../models/userModel')
const jwt = require('jsonwebtoken');


const createToken = (_id) => {
  return jwt.sign({_id}, process.env.SECRET,{expiresIn:'3d'})
} 
//LogIn user
const userLogin = async (req, res) => {
  const {email, password} = req.body

  try{
      const user = await User.logIn(email,password)
      //criar token
      const token = createToken(user._id)


      res.status(200).json({email, token})
  }catch(error){
      res.status(400).json({error: error.message})
  }
}

const userSignUp = async (req, res) => {
  const { email, password, category, name } = req.body;
  try {
    const user = await User.signUp(email, password,name);

    // Create token
    const token = createToken(user._id);

    res.status(200).json({ name, email, token, category });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
// funcao para  area administrativa
const adminArea = (req,res) =>{
  return res.Status(200).json({message:'Bem Vindo a area administrativa'})
}

// funcao para area de cashier
const cashierArea = (res,req) =>{
  return res.Status(200).json({message:'Bem Vindo'})
}

module.exports = { userSignUp, userLogin , adminArea, cashierArea};
