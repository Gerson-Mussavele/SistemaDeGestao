

const authorize = (requriredCategory) =>{
  return(req,res,next) =>{
    if(req.User.category === 'Admin' || req.User.category === requriredCategory){
      return next()
    }else{
      return res.status(403).json({message:'Acess deneid'})
    }
  }
}


module.exports = {authorize}

