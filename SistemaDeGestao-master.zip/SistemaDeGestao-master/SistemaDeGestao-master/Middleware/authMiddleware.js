const jwt = require('jsonwebtoken')

const authMiddleware = (req,res,next) =>{
  const token = req.headers['authorization']
  if(!token){
    return res.status(401).json({message:'authentication is necessary'})
  }
  try{
    const decoded = jwt.verify(token.split(' ')[1],'My secret key')
    req.User = decoded;
    next()
  }catch(error){
    return res.status(401).json({message:'token invalido'})
  }
}
module.exports = {authMiddleware}